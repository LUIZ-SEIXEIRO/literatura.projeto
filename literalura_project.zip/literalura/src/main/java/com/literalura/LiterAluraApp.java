package com.literalura;

public class LiterAluraApp {
    public static void main(String[] args) {
        System.out.println("Bem vindo ao LiterAlura!");
        //Aqui virá a implementação do menu e as chamadas do sistema
    }
}
